// Copyright 2022 Mega Mind (@megamind4089)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#define CH_CFG_ST_RESOLUTION 16
#define CH_CFG_ST_FREQUENCY 10000

#include_next <chconf.h>
